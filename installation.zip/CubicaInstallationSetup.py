import os
import sys
import shutil
import urllib.request
import zipfile
from pathlib import Path
import subprocess

# --- BLOC AUTO-ELEVATION MODE ADMINISTRATEUR ---
def verifier_et_forcer_admin():
    if os.name == 'nt':
        import ctypes
        try:
            is_admin = ctypes.windll.shell32.IsUserAnAdmin()
        except:
            is_admin = False
            
        if not is_admin:
            print("Demande des droits Administrateur...")
            ctypes.windll.shell32.ShellExecuteW(
                None, "runas", sys.executable, " ".join(sys.argv), None, 1
            )
            sys.exit(0)

verifier_et_forcer_admin()

# --- BLOC D INSTALLATION DE PYTHON SUR WINDOWS ---
def installer_python_windows_systeme():
    return True

installer_python_windows_systeme()

# --- BLOC DE GESTION DES PREREQUIS ET DEPENDANCES ---
def installer_dependances():
    libs = ["PyQt5", "ursina", "sqlalchemy", "deep_translator", "perlin-noise"]
    print("Verification et installation des dependances en cours...")
    
    for lib in libs:
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", lib])
        except Exception:
            print("Erreur lors de l installation de la librairie")

installer_dependances()

# --- INTERFACE GRAPHIQUE ET LOGIQUE DE TELECHARGEMENT ---
from PyQt5 import QtCore, QtGui, QtWidgets

class ValidateurCertificat(urllib.request.HTTPSHandler):
    def __init__(self):
        import ssl
        context = ssl._create_unverified_context()
        super().__init__(context=context)

class WorkerTelechargement(QtCore.QThread):
    changement_progression = QtCore.pyqtSignal(int)
    changement_statut = QtCore.pyqtSignal(str)
    travail_termine = QtCore.pyqtSignal()

    def run(self):
        cubica_dir = Path.home() / "Cubica"
        if not cubica_dir.exists():
            cubica_dir.mkdir(parents=True, exist_ok=True)
            self.changement_statut.emit("Dossier Cubica cree")
        
        github_url = "https://github.com/w-studio-o/cubica-assets/archive/refs/heads/main.zip"
        zip_tmp = cubica_dir / "cubica_release.zip"
        
        self.changement_statut.emit("Connexion a GitHub...")
        try:
            req = urllib.request.Request(github_url, headers={'User-Agent': 'Mozilla/5.0'})
            opener = urllib.request.build_opener(urllib.request.ProxyHandler(), ValidateurCertificat())
            
            with opener.open(req) as reponse:
                taille_totale = int(reponse.headers.get('content-length', 0))
                taille_telechargee = 0
                bloc_taille = 8192
                
                with open(zip_tmp, 'wb') as f_out:
                    while True:
                        bloc = reponse.read(bloc_taille)
                        if not bloc:
                            break
                        f_out.write(bloc)
                        taille_telechargee += len(bloc)
                        
                        if taille_totale > 0:
                            pourcentage = int((taille_telechargee / taille_totale) * 100)
                            self.changement_progression.emit(int(pourcentage * 0.9))
            
            self.changement_statut.emit("Extraction des fichiers de la release...")
            self.changement_progression.emit(92)
            
            extract_temp = cubica_dir / "temp_extract"
            with zipfile.ZipFile(zip_tmp, 'r') as zip_ref:
                zip_ref.extractall(extract_temp)
            
            # REAJUSTEMENT : Cibler directement le dossier cubica-assets-main cree par GitHub
            dossier_github_intermediaire = extract_temp / "cubica-assets-main"
            
            if dossier_github_intermediaire.exists() and dossier_github_intermediaire.is_dir():
                # On deplace tout ce qui est a l'interieur de cubica-assets-main vers la racine de Cubica
                for item in dossier_github_intermediaire.iterdir():
                    shutil.move(str(item), str(cubica_dir))
            else:
                # Securite au cas ou le nom du dossier est different
                for item in extract_temp.iterdir():
                    if item.is_dir():
                        for sub_item in item.iterdir():
                            shutil.move(str(sub_item), str(cubica_dir))
                    else:
                        shutil.move(str(item), str(cubica_dir))
            
            # Nettoyage des dossiers temporaires d'extraction
            if extract_temp.exists():
                shutil.rmtree(extract_temp)
            if zip_tmp.exists():
                os.remove(zip_tmp)
                
        except Exception:
            print("Erreur de telechargement ou lien non defini")
            self.changement_statut.emit("Erreur lors du telechargement des assets")
        
        self.changement_statut.emit("Nettoyage des fichiers temporaires...")
        self.changement_progression.emit(98)
        
        compteur = 0
        for fichier_del in cubica_dir.rglob("DELETABLE.del"):
            try:
                if fichier_del.is_file():
                    fichier_del.unlink()
                    compteur += 1
            except Exception:
                print("Impossible de supprimer un fichier de configuration")
                
        print(f"Nettoyage effectue : {compteur} fichiers supprimes")
        
        self.changement_progression.emit(100)
        self.changement_statut.emit("Installation terminee avec succes !")
        self.travail_termine.emit()

class EcranInstallationCubica(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()
        
    def init_ui(self):
        self.setObjectName("EcranInstallation")
        self.resize(450, 200)
        self.setWindowTitle("CUBICA - Assistant d installation complete")
        
        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(25, 25, 25, 25)
        
        self.label_statut = QtWidgets.QLabel("Preparation de l installation...", self)
        self.label_statut.setStyleSheet("font-size: 12px; font-weight: bold;")
        layout.addWidget(self.label_statut)
        
        self.barre_progression = QtWidgets.QProgressBar(self)
        self.barre_progression.setValue(0)
        self.barre_progression.setTextVisible(True)
        layout.addWidget(self.barre_progression)
        
        self.bouton_quitter = QtWidgets.QPushButton("Quitter", self)
        self.bouton_quitter.setEnabled(False)
        self.bouton_quitter.clicked.connect(self.close)
        layout.addWidget(self.bouton_quitter)
        
        self.worker = WorkerTelechargement()
        self.worker.changement_progression.connect(self.mettre_a_jour_barre)
        self.worker.changement_statut.connect(self.mettre_a_jour_statut)
        self.worker.travail_termine.connect(self.installation_finie)
        self.worker.start()

    def mettre_a_jour_barre(self, valeur):
        self.barre_progression.setValue(valeur)

    def mettre_a_jour_statut(self, texte):
        self.label_statut.setText(texte)

    def installation_finie(self):
        self.bouton_quitter.setEnabled(True)
        self.bouton_quitter.setText("Terminer")

def main():
    app = QtWidgets.QApplication(sys.argv)
    fenetre = EcranInstallationCubica()
    fenetre.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()